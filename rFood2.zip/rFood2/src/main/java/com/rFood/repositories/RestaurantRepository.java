package com.rFood.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rFood.models.Item;
import com.rFood.models.Restaurant;

@Repository
public interface RestaurantRepository extends JpaRepository<Restaurant, Integer>{

	Restaurant getByRestaurantEmail(String restaurantEmail);

	Restaurant getByRestaurantId(int id);
	
}
