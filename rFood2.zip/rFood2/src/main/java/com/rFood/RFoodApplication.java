package com.rFood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RFoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(RFoodApplication.class, args);
	}

}
