package com.rFood.models;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int customerId;
	private String customerName;
	private String customerPhoneNumber;
	@Column(unique = true)
	private String customerEmail;
	private String customerPassword;
	private String customerArea;
	private String customerCity;
	private String customerPincode;
	
	@OneToOne(cascade = CascadeType.ALL)
	private FoodCart cart;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(String customerName, String customerPhoneNumber, String customerEmail, String customerPassword,
			String customerArea, String customerCity, String customerPincode, FoodCart cart) {
		super();
		this.customerName = customerName;
		this.customerPhoneNumber = customerPhoneNumber;
		this.customerEmail = customerEmail;
		this.customerPassword = customerPassword;
		this.customerArea = customerArea;
		this.customerCity = customerCity;
		this.customerPincode = customerPincode;
		this.cart = cart;
	}

	public Customer(int customerId, String customerName, String customerPhoneNumber, String customerEmail,
			String customerPassword, String customerArea, String customerCity, String customerPincode, FoodCart cart) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPhoneNumber = customerPhoneNumber;
		this.customerEmail = customerEmail;
		this.customerPassword = customerPassword;
		this.customerArea = customerArea;
		this.customerCity = customerCity;
		this.customerPincode = customerPincode;
		this.cart = cart;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}

	public void setCustomerPhoneNumber(String customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	public String getCustomerArea() {
		return customerArea;
	}

	public void setCustomerArea(String customerArea) {
		this.customerArea = customerArea;
	}

	public String getCustomerCity() {
		return customerCity;
	}

	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}

	public String getCustomerPincode() {
		return customerPincode;
	}

	public void setCustomerPincode(String customerPincode) {
		this.customerPincode = customerPincode;
	}

	public FoodCart getCart() {
		return cart;
	}

	public void setCart(FoodCart cart) {
		this.cart = cart;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerPhoneNumber="
				+ customerPhoneNumber + ", customerEmail=" + customerEmail + ", customerPassword=" + customerPassword
				+ ", customerArea=" + customerArea + ", customerCity=" + customerCity + ", customerPincode="
				+ customerPincode + ", cart=" + cart + "]";
	}
		
}
