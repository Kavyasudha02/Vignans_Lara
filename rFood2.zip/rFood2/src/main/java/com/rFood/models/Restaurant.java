package com.rFood.models;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Restaurant {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int restaurantId;
	private String restaurantName;
	private String restaurantPhoneNumber;
	private String restaurantOwnerName;
	@Column(unique = true)
	private String restaurantEmail;
	private String restaurantPassword;
	private String restaurantArea;
	private String restaurantCity;
	private String restaurantPincode;
	private String restUrl;
	
	@OneToMany(targetEntity = Item.class, cascade = CascadeType.ALL)
	private List<Item> menu;

	public Restaurant() {
		super();
	}

	public Restaurant(String restaurantName, String restaurantPhoneNumber, String restaurantOwnerName,
			String restaurantEmail, String restaurantPassword, String restaurantArea, String restaurantCity,
			String restaurantPincode, String restUrl, List<Item> menu) {
		super();
		this.restaurantName = restaurantName;
		this.restaurantPhoneNumber = restaurantPhoneNumber;
		this.restaurantOwnerName = restaurantOwnerName;
		this.restaurantEmail = restaurantEmail;
		this.restaurantPassword = restaurantPassword;
		this.restaurantArea = restaurantArea;
		this.restaurantCity = restaurantCity;
		this.restaurantPincode = restaurantPincode;
		this.restUrl = restUrl;
		this.menu = menu;
	}

	public Restaurant(int restaurantId, String restaurantName, String restaurantPhoneNumber, String restaurantOwnerName,
			String restaurantEmail, String restaurantPassword, String restaurantArea, String restaurantCity,
			String restaurantPincode, String restUrl, List<Item> menu) {
		super();
		this.restaurantId = restaurantId;
		this.restaurantName = restaurantName;
		this.restaurantPhoneNumber = restaurantPhoneNumber;
		this.restaurantOwnerName = restaurantOwnerName;
		this.restaurantEmail = restaurantEmail;
		this.restaurantPassword = restaurantPassword;
		this.restaurantArea = restaurantArea;
		this.restaurantCity = restaurantCity;
		this.restaurantPincode = restaurantPincode;
		this.restUrl = restUrl;
		this.menu = menu;
	}

	public int getRestaurantId() {
		return restaurantId;
	}

	public void setRestaurantId(int restaurantId) {
		this.restaurantId = restaurantId;
	}

	public String getRestaurantName() {
		return restaurantName;
	}

	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}

	public String getRestaurantPhoneNumber() {
		return restaurantPhoneNumber;
	}

	public void setRestaurantPhoneNumber(String restaurantPhoneNumber) {
		this.restaurantPhoneNumber = restaurantPhoneNumber;
	}

	public String getRestaurantOwnerName() {
		return restaurantOwnerName;
	}

	public void setRestaurantOwnerName(String restaurantOwnerName) {
		this.restaurantOwnerName = restaurantOwnerName;
	}

	public String getRestaurantEmail() {
		return restaurantEmail;
	}

	public void setRestaurantEmail(String restaurantEmail) {
		this.restaurantEmail = restaurantEmail;
	}

	public String getRestaurantPassword() {
		return restaurantPassword;
	}

	public void setRestaurantPassword(String restaurantPassword) {
		this.restaurantPassword = restaurantPassword;
	}

	public String getRestaurantArea() {
		return restaurantArea;
	}

	public void setRestaurantArea(String restaurantArea) {
		this.restaurantArea = restaurantArea;
	}

	public String getRestaurantCity() {
		return restaurantCity;
	}

	public void setRestaurantCity(String restaurantCity) {
		this.restaurantCity = restaurantCity;
	}

	public String getRestaurantPincode() {
		return restaurantPincode;
	}

	public void setRestaurantPincode(String restaurantPincode) {
		this.restaurantPincode = restaurantPincode;
	}

	public String getRestUrl() {
		return restUrl;
	}

	public void setRestUrl(String restUrl) {
		this.restUrl = restUrl;
	}

	public List<Item> getMenu() {
		return menu;
	}

	public void setMenu(List<Item> menu) {
		this.menu = menu;
	}

	@Override
	public String toString() {
		return "Restaurant [restaurantId=" + restaurantId + ", restaurantName=" + restaurantName
				+ ", restaurantPhoneNumber=" + restaurantPhoneNumber + ", restaurantOwnerName=" + restaurantOwnerName
				+ ", restaurantEmail=" + restaurantEmail + ", restaurantPassword=" + restaurantPassword
				+ ", restaurantArea=" + restaurantArea + ", restaurantCity=" + restaurantCity + ", restaurantPincode="
				+ restaurantPincode + ", restUrl=" + restUrl + ", menu=" + menu + "]";
	}	
}
