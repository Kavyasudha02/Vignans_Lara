package com.rFood.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Item {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int itemId;
	private String itemName;
	private Double itemPrice;
	private int quantity;
	private boolean itemAvailability;
	private String url;
	
	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Item(String itemName, Double itemPrice, int quantity, boolean itemAvailability, String url) {
		super();
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.quantity = quantity;
		this.itemAvailability = itemAvailability;
		this.url = url;
	}

	public Item(int itemId, String itemName, Double itemPrice, int quantity, boolean itemAvailability, String url) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.quantity = quantity;
		this.itemAvailability = itemAvailability;
		this.url = url;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Double getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(Double itemPrice) {
		this.itemPrice = itemPrice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public boolean isItemAvailability() {
		return itemAvailability;
	}

	public void setItemAvailability(boolean itemAvailability) {
		this.itemAvailability = itemAvailability;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemName=" + itemName + ", itemPrice=" + itemPrice + ", quantity="
				+ quantity + ", itemAvailability=" + itemAvailability + ", url=" + url + "]";
	}
	
}
