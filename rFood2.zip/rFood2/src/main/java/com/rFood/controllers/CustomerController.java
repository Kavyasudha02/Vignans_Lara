package com.rFood.controllers;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rFood.exceptions.CustomerException;
import com.rFood.models.Customer;
import com.rFood.services.CustomerService;

import jakarta.servlet.http.HttpSession;

@Controller
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	private static final Logger logger = LogManager.getLogger("CustomerController.class");
	
	@GetMapping("/viewCustomerProfile")
	public String viewCustomerProfile(HttpSession session, Model model) throws CustomerException {
		int customerId = (int) session.getAttribute("id");
		Customer customer = customerService.getByCustomerId(customerId);
		model.addAttribute("customer",customer);
		return "customerProfile";
	}
	@GetMapping("/updateCustomerForm")
	public String updateCustomerForm(HttpSession session, Model model) throws CustomerException {
		int customerId = (int)session.getAttribute("id");
		Customer customer = customerService.getByCustomerId(customerId);
		model.addAttribute("customer", customer);
		return "updateCustomer";
	}
	
	@PostMapping("/saveUpdateCustomer")
	public String saveUpdateCustomer(@ModelAttribute Customer customer,HttpSession session) throws CustomerException {
		customerService.saveCustomer(customer);
		return "redirect:/viewCustomerProfile";
	}
	
	@GetMapping("/viewRegisterCustomer")
	public String showRegisterCustomer(Model model) {
		Customer customer = new Customer();
		model.addAttribute("customer", customer.getCustomerName());
		logger.info("Customer details updated");
		return "registerCustomer";
	}
	
	@PostMapping("/saveCustomer")
	public String saveCustomer(@ModelAttribute("customer") Customer customer, Model model) throws CustomerException {
		
		if(customer.getCustomerEmail() != null) {
			customerService.saveCustomer(customer);
			logger.info("Customer Registered with name:{}",customer.getCustomerName());
			return "redirect:/viewCustomerLogIn";
		}
		else {
			throw new CustomerException("Invalid Details");
		}
	}
	
	@PostMapping("/viewCustomerHome")
	public String showCustomerHome(@RequestParam String customerEmail,@RequestParam String customerPassword, HttpSession session, Model model) throws CustomerException {
		Customer customer = customerService.getByCustomerEmail(customerEmail);
		if(customer!=null && customer.getCustomerPassword().equals(customerPassword)) {
			session.setAttribute("id",customer.getCustomerId());
			logger.info("Customer Logged in:{}",customer);
			return "customerHome";
		}else {
			throw new CustomerException("Invalid Email or Password");
		}
	}
	

}
