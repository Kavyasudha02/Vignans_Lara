package com.rFood.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rFood.exceptions.ItemException;
import com.rFood.exceptions.RestaurantException;
import com.rFood.models.Item;
import com.rFood.models.Restaurant;
import com.rFood.services.ItemService;
import com.rFood.services.RestaurantService;

import jakarta.servlet.http.HttpSession;

@Controller
public class ItemController {

	@Autowired
	ItemService itemService;

	@Autowired
	RestaurantService restaurantService;

	private static final Logger logger = LogManager.getLogger("ItemController.class");

	@GetMapping("/viewManageItems")
	public String showManageItems() {
		return "manageItems";
	}

	@GetMapping("/viewAddItems")
	public String showAddFoodItems(Model model) {
		Item item = new Item();
		model.addAttribute(item);
		return "addFoodItems";
	}

	@PostMapping("/saveItem")
	public String saveRestaurant(@ModelAttribute Item item, HttpSession session, Model model)
			throws RestaurantException {
		if (session.getAttribute("id") != null) {
			int restaurantId = (int) session.getAttribute("id");
			itemService.save(item);
			Restaurant restaurant = restaurantService.getRestaurantById(restaurantId);
			restaurant.getMenu().add(item);
			logger.info("1 item saved:{}", item.getItemName());
			restaurantService.saveRestaurant(restaurant);
		}
		return "redirect:/viewAddItems";
	}

	@GetMapping("/viewItems")
	public String showItems(HttpSession session, Model model) throws RestaurantException, ItemException {
		Restaurant restaurant = restaurantService.getRestaurantById((int) session.getAttribute("id"));
		List<Item> itemsList = restaurant.getMenu();
		model.addAttribute("itemsList", itemsList);
		return "items";
	}

	@GetMapping("/updateRestauarntItem/{id}")
	public String updateRestaurantItem(@PathVariable(value = "id") int id, Model model, HttpSession session)
			throws ItemException {
		Item item = itemService.getItemById(id);
		model.addAttribute("item", item);
		return "updateRestaurantItems";
	}

	@PostMapping("/updateItem")
	public String updateItem(@ModelAttribute Item item, HttpSession session) throws ItemException, RestaurantException {
		itemService.save(item);
		logger.info("1 item updated:{}", item.getItemName());
		return "redirect:/viewItems";
	}

	@GetMapping("/deleteRestaurantItem/{id}")
	public String deleteItem(@PathVariable(value = "id") int id, HttpSession session)
			throws ItemException, RestaurantException {
		Item item = itemService.getItemById(id);
		int restaurantId = (int) session.getAttribute("id");
		Restaurant restaurant = restaurantService.getRestaurantById(restaurantId);
		restaurant.getMenu().remove(item);
		itemService.deleteItem(item);
		restaurantService.saveRestaurant(restaurant);
		logger.info("1 item deleted");
		return "redirect:/viewItems";
	}

	@PostMapping("/customerViewFoodItems")
	public String customerViewFoodItems(@RequestParam String itemName, Model model) {
		Map<Item,Restaurant> availablerest = new HashMap<>();
		Map<Item,Restaurant> notavailablerest = new HashMap<>();
		List<Restaurant> restaurants = restaurantService.findAll();
		for (Restaurant restaurant : restaurants) {
			List<Item> items = restaurant.getMenu();
			for (Item item : items) {
				String s1 = itemName.replaceAll("\\s", "");
				String s2 = item.getItemName().replaceAll("\\s", "");
				if (s2.equalsIgnoreCase(s1)) {
					availablerest.put(item, restaurant);
				} else {
					notavailablerest.put(item, restaurant);
				}
			}
		}
		logger.info("searched item:{}", itemName);
		model.addAttribute("notavailablerest",notavailablerest);
		model.addAttribute("availablerest", availablerest);
		return "customerViewItems";
	}

	@GetMapping("customerViewRestaurantsFromItems/{id}")
	public String viewRestaurantItems(@PathVariable(value = "id") int restaurantid, Model model)
			throws RestaurantException {
		Restaurant restaurant = restaurantService.getRestaurantById(restaurantid);
		List<Item> itemsList = restaurant.getMenu();
		model.addAttribute("itemsList", itemsList);
		return "customerViewRestaurantsItems2";

	}

	@PostMapping("/customerViewRestaurants")
	public String customerViewRestaurants(@RequestParam(required = false) String restaurantName, Model model)
			throws RestaurantException {
		Restaurant restaurant = restaurantService.getRestaurantByName(restaurantName);
		if(restaurant != null) {
			List<Item> itemsList = restaurant.getMenu();
			model.addAttribute("itemsList", itemsList);
			logger.info("searched restaurant:{}", restaurantName);
			return "customerViewRestaurantItems";
		}else {
			throw new RestaurantException("Restaurant not Found");
		}
		
	}

}
