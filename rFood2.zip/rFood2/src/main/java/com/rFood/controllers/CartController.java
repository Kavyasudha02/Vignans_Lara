package com.rFood.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rFood.exceptions.CartException;
import com.rFood.exceptions.CustomerException;
import com.rFood.exceptions.ItemException;
import com.rFood.models.Customer;
import com.rFood.models.FoodCart;
import com.rFood.models.Item;
import com.rFood.models.Restaurant;
import com.rFood.services.CustomerService;
import com.rFood.services.FoodCartService;
import com.rFood.services.ItemService;
import com.rFood.services.RestaurantService;

import jakarta.servlet.http.HttpSession;

@Controller
public class CartController {

	@Autowired
	ItemService itemService;

	@Autowired
	CustomerService customerService;

	@Autowired
	FoodCartService cartService;

	@Autowired
	RestaurantService restaurantService;

	private static final Logger logger = LogManager.getLogger("CartController.class");

	@PostMapping("/add")
	public String addCart(@RequestParam int itemId, @RequestParam int itemQuantity, HttpSession session, Model model)
			throws CustomerException, ItemException, CartException {

		if (session.getAttribute("id") != null) {

			int customerId = (int) session.getAttribute("id");
			Customer customer = customerService.getByCustomerId(customerId);

			Item item = itemService.getItemById(itemId);
			FoodCart cart = cartService.getCartByCustomerId(customerId);
			item.setQuantity(itemQuantity);
			itemService.save(item);

			if (item.isItemAvailability()) {

				if (cart == null) {
					List<Item> cartItem = new ArrayList<>();
					cartItem.add(item);
					cartService.save(customer, cartItem);
				} else {
					cart.getItemList().add(item);
					cartService.saveCart(cart);
				}
				logger.info("1 item added to Cart:{}", item.getItemName());
				return "redirect:/showCart";
			} else {
				logger.warn("Item not found");
				return "itemUnailablePage";
			}
		} else {

			return "redirect:/viewCustomerLogIn";
		}

	}

	@GetMapping("/showCart")
	public String viewCart(HttpSession session, Model model) {
		HashMap<Item, Restaurant> itemList = new HashMap<>();
		int customerId = (int) session.getAttribute("id");
		FoodCart cart = cartService.getCartByCustomerId(customerId);
		if (cart != null) {
			List<Item> items = cart.getItemList();
			for (Item item : cart.getItemList()) {
				Restaurant restaurant = restaurantService.getRestaurantByItem(item.getItemId());
				itemList.put(item, restaurant);
			}
			model.addAttribute("items", items);
			model.addAttribute("itemList", itemList);
			logger.info("opened cart");
			return "itemAdded";
		}
		return "itemAdded";
	}

	@GetMapping("/deleteFromCart/{id}")
	public String deleteCart(@PathVariable(value = "id") int itemId, HttpSession session)
			throws CartException, CustomerException, ItemException {

		int customerId = (int) session.getAttribute("id");
		FoodCart cart = cartService.getCartByCustomerId(customerId);
		int cartId = cart.getCartId();
		cartService.deleteItemFromCart(cartId, itemId);
		logger.warn("Item deleted from cart");
		return "redirect:/showCart";
	}

}
