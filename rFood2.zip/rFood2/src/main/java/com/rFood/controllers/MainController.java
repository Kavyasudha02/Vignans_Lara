package com.rFood.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class MainController {
	
	@GetMapping("/")
	public String viewIndex(HttpServletRequest req) {
		HttpSession session = req.getSession();
		session.setAttribute("id", null);
		return "index";
	}
	
	@GetMapping("/viewAbout")
	public String showAbout() {
		return "about";
	}
	
	@GetMapping("/viewHome")
	public String viewHome(HttpSession session) {
		if(session.getAttribute("id")== null) {
			return "redirect:/";
		}else {
			return "redirect:/viewCustomerHome";
		}
	}

	@GetMapping("/viewHomeCart")
	public String showHomeCart() {
		return "homeCart";
	}

	@GetMapping("/viewContact")
	public String showContact() {
		return "contact";
	}

	@GetMapping("/viewContactFromCustomer")
	public String showContactFromCustomer() {
		return "contactFromCustomer";
	}

	@GetMapping("/viewAboutFromCustomer")
	public String showAboutfromCustomer() {
		return "aboutFromCustomer";
	}

	@GetMapping("/viewContactFromRestaurant")
	public String showContactFromRestaurant() {
		return "contactFromRestaurant";
	}

	@GetMapping("/viewAboutFromRestaurant")
	public String showAboutfromRestaurant() {
		return "aboutFromRestaurant";
	}

	@GetMapping("/viewCustomerHome")
	public String showCustomerHome1() {
		return "customerHome";
	}

	@GetMapping("/viewRestaurantHome")
	public String showRestaurantHome1() {
		return "restaurantHome";
	}
}
