package com.rFood.controllers;

import java.time.LocalDateTime;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.rFood.exceptions.CartException;
import com.rFood.exceptions.CustomerException;
import com.rFood.models.Customer;
import com.rFood.models.FoodCart;
import com.rFood.models.Item;
import com.rFood.models.OrderDetails;
import com.rFood.models.Restaurant;
import com.rFood.services.CustomerService;
import com.rFood.services.FoodCartService;
import com.rFood.services.OrderDetailsService;
import com.rFood.services.RestaurantService;

import jakarta.servlet.http.HttpSession;

@Controller
public class OrderController {

	@Autowired
	CustomerService customerService;

	@Autowired
	FoodCartService cartService;

	@Autowired
	RestaurantService restaurantService;

	@Autowired
	OrderDetailsService orderService;

	private static final Logger logger = LogManager.getLogger("OrderController.class");

	@PostMapping("/placeOrder")
	public String placeOrder(Model model, HttpSession session) throws CustomerException {
		if (session.getAttribute("id") != null) {
			int customerId = (int) session.getAttribute("id");
			Customer customer = customerService.getByCustomerId(customerId);
			FoodCart cart = cartService.getCartByCustomerId(customerId);
			LocalDateTime orderDate = LocalDateTime.now();
			String msg = "ACCEPTED";
			List<Item> cartItems = cart.getItemList();
			double price = 0;
			for (Item item : cartItems) {
				price += item.getItemPrice() * item.getQuantity();
				Restaurant restaurant = restaurantService.getRestaurantByItem(item.getItemId());
				OrderDetails order = new OrderDetails(orderDate, msg, item, customer, restaurant);
				orderService.save(order);
			}
			model.addAttribute("price", price);
			model.addAttribute("customer", customer);
			return "proceedToPay";

		} else {
			return "redirect:/redirect:/viewCustomerLogIn";
		}
	}

	@PostMapping("/proceedToPay")
	public String ProceedToPay(HttpSession session) throws CustomerException, CartException {
		int customerId = (int) session.getAttribute("id");
		FoodCart cart = cartService.getCartByCustomerId(customerId);
		cart.getItemList().clear();
		cartService.save(cart);
		logger.info("order Placed");
		return "paymentDonePage";
	}

	@GetMapping("/orderHistoryForCustomer")
	public String viewOrderHistoryForCustomer(HttpSession session, Model model) throws CustomerException {
		int customerId = (int) session.getAttribute("id");
		List<OrderDetails> customerOrders = orderService.getOrdersByCustomerId(customerId);
		model.addAttribute("customerOrders", customerOrders);
		logger.info("Customer view Order History");
		return "myOrders";
	}

	@GetMapping("/viewManageOrders")
	public String showManageOrder(HttpSession session, Model model) {
		int restaurantId = (int) session.getAttribute("id");
		List<OrderDetails> restaurantOrders = orderService.getOrdersByRestaurantId(restaurantId);
		model.addAttribute("restaurantOrders", restaurantOrders);
		logger.info("Restaurant view Orders");
		return "orderHistory";
	}

	@GetMapping("/updateOrderStatus/{id}")
	public String updateOrderStatus(@PathVariable("id") int orderId, Model model) {
		OrderDetails order = orderService.getByOrderId(orderId);
		model.addAttribute("order", order);
		return "changeOrderStatus";
	}

	@PostMapping("/updateStatus")
	public String updateStatus(@ModelAttribute OrderDetails order) {
		orderService.save(order);
		logger.info("Restaurant change status for order:{}", order);
		return "redirect:/viewManageOrders";
	}
}
