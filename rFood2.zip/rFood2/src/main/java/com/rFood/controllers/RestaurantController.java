package com.rFood.controllers;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rFood.exceptions.RestaurantException;
import com.rFood.models.Restaurant;
import com.rFood.services.ItemService;
import com.rFood.services.RestaurantService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;


@Controller
public class RestaurantController {	
	
	@Autowired
	RestaurantService restaurantService;
	@Autowired 
	ItemService itemService;
	
	private static final Logger logger = LogManager.getLogger("RestaurantController.class");
	
	@GetMapping("/viewRestaurantProfile")
	public String viewCustomerProfile(HttpSession session, Model model) throws RestaurantException {
		int restaurantId = (int) session.getAttribute("id");
		Restaurant restaurant = restaurantService.getRestaurantById(restaurantId);
		model.addAttribute("restaurant",restaurant);
		return "restaurantProfile";
	}
	@GetMapping("/updateRestaurantForm")
	public String updateCustomerForm(HttpSession session, Model model) throws RestaurantException {
		int restaurantId = (int) session.getAttribute("id");
		Restaurant restaurant = restaurantService.getRestaurantById(restaurantId);
		model.addAttribute("restaurant",restaurant);
		return "updateRestaurant";
	}
	
	@PostMapping("/saveUpdateRestaurant")
	public String saveUpdateCustomer(@ModelAttribute Restaurant restaurant,HttpSession session) throws RestaurantException {
		restaurantService.saveRestaurant(restaurant);
		return "redirect:/viewRestaurantProfile";
	}
	
	@GetMapping("/viewRegisterRestaurant")
	public String showRegisterRestaurant(Model model) {
		Restaurant restaurant = new Restaurant();
		model.addAttribute("restaurant", restaurant);
		return "registerRestaurant";
	}
	@PostMapping("/saveRestaurant")
	public String saveRestaurant(@ModelAttribute("restaurant") Restaurant restaurant, Model model) throws RestaurantException {
		
		if(restaurantService.getByRestaurantEmail(restaurant.getRestaurantEmail()) != null) {
			String error = "This EmailId already in exist login to continue";
			model.addAttribute("error",error);
			System.out.println("email" + restaurant);
			logger.info("Restaurant Registered with name:{}",restaurant.getRestaurantName());
			return "redirect:/viewRestaurantLogIn";
		}
		else {
			restaurantService.saveRestaurant(restaurant);
			System.out.println("Saving restaurant");
			return "redirect:/viewRestaurantLogIn";
		}
	}
	@PostMapping("/viewRestaurantHome")
	public String showRestaurantHome(@RequestParam String restaurantEmail, @RequestParam String restaurantPassword,
			HttpServletRequest request, Model model) throws RestaurantException {
		Restaurant restaurant = restaurantService.getByRestaurantEmail(restaurantEmail);
		if (restaurant != null && restaurant.getRestaurantPassword().equals(restaurantPassword)) {
			HttpSession session = request.getSession();
			session.setAttribute("id", restaurant.getRestaurantId());
			session.setAttribute("restaurantEmail",restaurant.getRestaurantEmail() );
			logger.info("Restaurant LogIn with name:{}",restaurant.getRestaurantName());			
			return "restaurantHome";
		}
		return "redirect:/viewRestaurantLogIn";
	}

}
