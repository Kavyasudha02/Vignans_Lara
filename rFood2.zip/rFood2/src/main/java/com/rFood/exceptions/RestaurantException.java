package com.rFood.exceptions;

public class RestaurantException extends Exception {
	public RestaurantException() {
		super();
	}
	public RestaurantException(String message) {
		super(message);
	}

}
