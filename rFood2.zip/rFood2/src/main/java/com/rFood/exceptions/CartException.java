package com.rFood.exceptions;

public class CartException extends Exception{
	public CartException() {
		super();
	}
	public CartException(String message) {
		super(message);
	}

}
