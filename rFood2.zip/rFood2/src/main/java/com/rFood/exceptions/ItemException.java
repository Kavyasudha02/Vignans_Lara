package com.rFood.exceptions;

public class ItemException extends Exception{

	public ItemException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ItemException(String message) {
		super(message);
	}

}
