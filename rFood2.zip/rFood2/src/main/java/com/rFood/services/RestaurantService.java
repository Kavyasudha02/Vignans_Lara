package com.rFood.services;

import java.util.List;

import com.rFood.exceptions.RestaurantException;
import com.rFood.models.Restaurant;

public interface RestaurantService {

	Restaurant getByRestaurantEmail(String restaurantEmail) throws RestaurantException;

	Restaurant saveRestaurant(Restaurant restaurant);

	Restaurant getRestaurantById(int attribute) throws RestaurantException;

	List<Restaurant> findAll();

	Restaurant getRestaurantByName(String restaurantName) throws RestaurantException;

	Restaurant getRestaurantByItem(int itemId);

}
