package com.rFood.services;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rFood.exceptions.CustomerException;
import com.rFood.models.Customer;
import com.rFood.models.FoodCart;
import com.rFood.repositories.CustomerRepository;

@Service
public class CustomerServiceImplementation implements CustomerService{
	
	@Autowired
	CustomerRepository customerRepository;
	

	@Override
	public void saveCustomer(Customer customer) {
		
		customerRepository.save(customer);
	}

	@Override
	public Customer getByCustomerEmail(String customerEmail) throws CustomerException {
		Optional<Customer> optional = customerRepository.findByCustomerEmail(customerEmail);
		if(optional.isPresent()) {
			return optional.get();
		}else {
			throw new CustomerException("Email doen't Exist");
		}
	}

	@Override
	public Customer getByCustomerId(int customerId) throws CustomerException {
		
		Optional<Customer> optional = customerRepository.findById(customerId);
		
		if(optional.isPresent()) {
			return optional.get();
		}
		else {
			throw new CustomerException("The customer id not found");
		}
	}

}
