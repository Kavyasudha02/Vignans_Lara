package com.rFood.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rFood.exceptions.CartException;
import com.rFood.models.Customer;
import com.rFood.models.FoodCart;
import com.rFood.models.Item;
import com.rFood.repositories.FoodCartRepository;

@Service
public class FoodCartServiceImplementation implements FoodCartService{
	
	@Autowired
	FoodCartRepository foodCartRepository;
	
	@Override
	public FoodCart getCartByCustomerId(int customerId) {
		List<FoodCart> foodCart = foodCartRepository.findAll();
		for(FoodCart cart : foodCart) {
			
			if(cart.getCustomer().getCustomerId() == customerId) {
				
				return cart;
			}
		}
		return null;
	}

	@Override
	public void save(FoodCart cart) throws CartException {
		// TODO Auto-generated method stub
		this.foodCartRepository.save(cart);
	}

	@Override
	public void save(Customer customer, List<Item> cartItem) throws CartException {
		// TODO Auto-generated method stub
		FoodCart cart = new FoodCart(customer, cartItem);
		this.foodCartRepository.save(cart);
		
	}

	@Override
	public void deleteItemFromCart(int cartId, int itemId) throws CartException {
		Optional<FoodCart> cart = foodCartRepository.findById(cartId);
		if(cart.isPresent()) {
			FoodCart foodCart = cart.get();
			List<Item> items = foodCart.getItemList();
			items.removeIf(item -> item.getItemId() == (itemId));
			foodCartRepository.save(foodCart);
			
		}else {
			throw new CartException("No Cart Available");
		}
		
	}

	@Override
	public void saveCart(FoodCart cart) {
		this.foodCartRepository.save(cart);
	}

}
