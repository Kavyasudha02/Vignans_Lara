package com.rFood.services;

import java.util.List;

import com.rFood.exceptions.CartException;
import com.rFood.models.Customer;
import com.rFood.models.FoodCart;
import com.rFood.models.Item;

public interface FoodCartService {

	FoodCart getCartByCustomerId(int customerId);

	void save(FoodCart cart) throws CartException;

	void save(Customer customer, List<Item> cartItem) throws CartException;

	void deleteItemFromCart(int cartId, int itemId) throws CartException;

	void saveCart(FoodCart cart);

}
