package com.rFood.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rFood.exceptions.RestaurantException;
import com.rFood.models.Item;
import com.rFood.models.Restaurant;
import com.rFood.repositories.RestaurantRepository;

@Service
public class RestaurantServiceImplementation implements RestaurantService{
	
	@Autowired
	RestaurantRepository restaurantRepository;

	@Override
	public Restaurant getByRestaurantEmail(String restaurantEmail) throws RestaurantException {
		return restaurantRepository.getByRestaurantEmail(restaurantEmail);	
	}

	@Override
	public Restaurant saveRestaurant(Restaurant restaurant) {
		return restaurantRepository.save(restaurant);
	}

	@Override
	public Restaurant getRestaurantById(int id) throws RestaurantException {
		Optional<Restaurant> optional = restaurantRepository.findById(id);
		if(optional.isPresent()) {
			return optional.get();
		}
		
		throw new RestaurantException("Restaurant not found");
	}

	@Override
	public List<Restaurant> findAll() {
		List<Restaurant> restaurant =restaurantRepository.findAll();
		return restaurant;
	}

	@Override
	public Restaurant getRestaurantByName(String restaurantName) throws RestaurantException {
		List<Restaurant> allRestaurants = restaurantRepository.findAll();
		Restaurant restaurant = null;
		for(Restaurant res : allRestaurants) {
			if(res.getRestaurantName()!=null) {
			String resName = res.getRestaurantName().replaceAll("\\s", "");
			if(res.getRestaurantName().equalsIgnoreCase(restaurantName) || (resName.equalsIgnoreCase(restaurantName))) {
				
				restaurant = res;
			}
		}else {
			 throw new RestaurantException("Restaurant not found");
		}
		}
		return restaurant;

	}

	@Override
	public Restaurant getRestaurantByItem(int itemId) {
		List<Restaurant> allRestaurants = restaurantRepository.findAll();
		for(Restaurant res : allRestaurants) {
			
			for(Item item : res.getMenu()) {
				
				if(item.getItemId() == itemId) {
					
					return res;
				}
			}
		}
		return null;
	}

}
