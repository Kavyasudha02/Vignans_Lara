package com.rFood.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rFood.models.Item;
import com.rFood.models.Restaurant;
import com.rFood.repositories.ItemRepository;
import com.rFood.repositories.RestaurantRepository;

@Service
public class ItemServiceImplementation implements ItemService{
	
	@Autowired
	ItemRepository itemRepository;
	@Autowired
	RestaurantRepository restaurantRepository;

	@Override
	public void save(Item item) {
		itemRepository.save(item);	
	}

	@Override
	public Item getItemById(int id) {
		return itemRepository.getByItemId(id);
	}

	@Override
	public void deleteItem(Item item) {
		itemRepository.delete(item);
		
	}

}
