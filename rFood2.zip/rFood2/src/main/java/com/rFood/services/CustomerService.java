package com.rFood.services;

import com.rFood.exceptions.CustomerException;
import com.rFood.models.Customer;

public interface CustomerService {

	void saveCustomer(Customer customer);

	Customer getByCustomerEmail(String customerEmail) throws CustomerException;

	Customer getByCustomerId(int customerId)throws CustomerException;

}
