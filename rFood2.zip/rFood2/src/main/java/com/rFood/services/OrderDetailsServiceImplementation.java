package com.rFood.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rFood.models.OrderDetails;
import com.rFood.repositories.OrderDetailsRepository;

@Service
public class OrderDetailsServiceImplementation implements OrderDetailsService{
	
	@Autowired
	OrderDetailsRepository orderRepository;

	@Override
	public void save(OrderDetails order) {
		orderRepository.save(order);
		
	}

	@Override
	public List<OrderDetails> getOrdersByCustomerId(int customerId) {
		List<OrderDetails> orders = orderRepository.findAll();
		List<OrderDetails> customerOrder = new ArrayList<>();
		for(OrderDetails order : orders) {
			if(order.getCustomer().getCustomerId() == customerId) {
				customerOrder.add(order);
			}
		}
		return customerOrder;
	}

	@Override
	public List<OrderDetails> getOrdersByRestaurantId(int restaurantId) {
		List<OrderDetails> orders = orderRepository.findAll();
		List<OrderDetails> restaurantOrder = new ArrayList<>();
		for(OrderDetails order : orders) {
			if(order.getRestaurant().getRestaurantId() == restaurantId) {
				restaurantOrder.add(order);
			}
		}
		return restaurantOrder;
	}

	@Override
	public OrderDetails getByOrderId(int orderId) {
		OrderDetails order = orderRepository.getByOrderId(orderId);
		return order;
	}

}
