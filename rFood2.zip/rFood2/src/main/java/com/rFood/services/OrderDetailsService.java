package com.rFood.services;

import java.util.List;

import com.rFood.models.OrderDetails;

public interface OrderDetailsService {

	void save(OrderDetails order);

	List<OrderDetails> getOrdersByCustomerId(int customerId);

	List<OrderDetails> getOrdersByRestaurantId(int restaurantId);

	OrderDetails getByOrderId(int orderId);


}
