package com.rFood.services;

import com.rFood.models.Item;

public interface ItemService {

	void save(Item item);

	Item getItemById(int id);

	void deleteItem(Item item);

}
