package com.rFood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RFoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
